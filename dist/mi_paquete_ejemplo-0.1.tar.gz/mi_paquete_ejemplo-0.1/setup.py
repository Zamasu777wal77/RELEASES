from setuptools import setup, find_packages

setup(
    name="mi_paquete_ejemplo",
    version="0.1",
    packages=find_packages(),
    description="Un ejemplo simple de paquete",
    author="Tu Nombre",
    author_email="tunombre@example.com",
)
